salman ayiq 316200864
#include <stdio.h>
void main()
{
	char ch1,ch2;
	printf("enter two char:");
	ch1 = getchar();
	ch2 = getchar();
	printf("the number is:%d\n", ch2 - ch1);
}
/*enter two char:hs
the number is:11
Press any key to continue . . .*/